#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
cd $DIR


for values in $(echo '050401 070701 050501 010901 090101 050409 070709 050509 010909 090109')

do
    echo "PROGRAM system

EXTERNAL EQS, JAC
INTEGER IOPT, IOUT, ISTATE, ITASK, ITOL, IWORK(23), LIW, LRW, MF, NEQ
DOUBLE PRECISION ATOL(3), RTOL, RWORK(58), T, TOUT, Y(3)
!INTEGER, PARAMETER :: DP = SELECTED_REAL_KIND(15, 307)
!REAL(KIND=DP) :: Y(3)

NEQ = 3                 ! number of first-order ODE


T = 0.D0                ! initial value of independent variable t
TOUT = .0D0            ! next value of independent variable t
ITOL = 2                ! 1 indicates ATOL is scalar, 2 indicates ATOL is array
RTOL = 1.D-6            ! Relative tolerance

ATOL(1) = 1.D-6         ! Absolute tolerance for each i in Y(i)
ATOL(2) = 1.D-6
ATOL(3) = 1.D-6

ITASK = 1               ! Indicates that DLSODE is to compute output values of y
ISTATE = 1              ! ISTATE=1 for first call, ISTATE=2 for subsequent calls
                        ! Automatically updated to 2 if DLSODE was successful

IOPT = 0                ! IOPT=0 for no optional inputs, IOPT=1 for optional inputs
LRW = 68                ! Length of real work array
LIW = 23                ! Length of integer work array
MF = 21                 ! Method flag.  Possible values are:
                        ! 10  Nonstiff (Adams) method, no Jacobian used.
                        ! 21  Stiff (BDF) method, user-supplied full Jacobian.
                        ! 22  Stiff method, internally generated full Jacobian.
                        ! 24  Stiff method, user-supplied banded Jacobian.
                        ! 25  Stiff method, internally generated banded Jacobian.


20 FORMAT('t',E9.3,'y',E10.3,'x'E10.3,'n',E10.3)
! 20  FORMAT(D12.6,3D11.3)

Y(1) = 0.${values:1:1}             ! values of y(t) at t=t1
Y(2) = 0.${values:3:1}
Y(3) = 0.${values:5:1}
OPEN(1, FILE = '${values}.dat', status = 'UNKNOWN')

DO IOUT = 1,10000000!10000
    CALL DLSODE (EQS, NEQ, Y, T, TOUT, ITOL, RTOL, ATOL, ITASK, ISTATE, IOPT, RWORK, LRW, IWORK, LIW, JAC, MF)
    IF(MOD(IOUT, 10) == 0) THEN
        WRITE(1,20)  T, Y(1), Y(2), Y(3)
    ELSE
	CYCLE
    END IF

    IF(Y(1) < 0.01) Y(1) = 0
    IF(Y(2) < 0.01) Y(2) = 0
    IF(Y(3) < 0.01) Y(3) = 0
    IF(Y(1) > 0.99) Y(1) = 1
    IF(Y(2) > 0.99) Y(2) = 1
    IF(Y(3) > 0.99) Y(3) = 1

    IF (ISTATE .LT. 0)  GO TO 80
    TOUT = TOUT+.1D-3              ! Next time step
END DO
CLOSE(1)

! DO IOUT = 1,10000
!     CALL DLSODE (EQS, NEQ, Y, T, TOUT, ITOL, RTOL, ATOL, ITASK, ISTATE, IOPT, RWORK, LRW, IWORK, LIW, JAC, MF)
!     WRITE(6,20)  T, Y(1), Y(2), Y(3)
!     IF (ISTATE .LT. 0)  GO TO 80
!     TOUT = TOUT+.1D-1               ! Next time step
! END DO

WRITE(6,60)  IWORK(11), IWORK(12), IWORK(13), ISTATE
60  FORMAT(/' No. steps =',i4,',  No. f-s =',i4,',  No. J-s =',i4,', ISTATE returned =',i4)
STOP

! error handling
80  WRITE(6,90)  ISTATE
90  FORMAT(///' Error halt.. ISTATE =',I3)
STOP

!END
END PROGRAM system

SUBROUTINE  EQS (NEQ, T, Y, YDOT)
    ! Set array ydot
    INTEGER  NEQ
    DOUBLE PRECISION  T, Y(3), YDOT(3)

    YDOT(1) = Y(1)*(1 - Y(1))*(1.0*Y(3)*(1 - Y(1)) - 1.0*Y(3)*(1 - Y(2)) + Y(1)*(4.0 - 1.0*Y(3)) - Y(1)*(1.0*Y(3) + 3.0) &
     + Y(2)*(5.0 - 2.0*Y(3)) - Y(2)*(2.0*Y(3) + 3.0) - (1.0 - 1.0*Y(3))*(1 - Y(1)) + (1.0 - 1.0*Y(3))*(1 - Y(2)))
    YDOT(2) = Y(2)*(1 - Y(2))*(1.0*Y(3)*(1 - Y(1)) - 1.0*Y(3)*(1 - Y(2)) + Y(1)*(4.0 - 1.0*Y(3)) - Y(1)*(1.0*Y(3) + 3.0) &
     + Y(2)*(5.0 - 2.0*Y(3)) - Y(2)*(2.0*Y(3) + 3.0) - (1.0 - 1.0*Y(3))*(1 - Y(1)) + (1.0 - 1.0*Y(3))*(1 - Y(2)))
    YDOT(3) = Y(3)*(1 - Y(3))*(1.25*Y(1) + 1.25*Y(2) - 1)

    RETURN
END SUBROUTINE EQS

SUBROUTINE  JAC (NEQ, T, Y, ML, MU, PD, NRPD)
    ! Set JacobiaY(3) matriY(1)
    INTEGER  NEQ, ML, MU, NRPD
    DOUBLE PRECISION  T, Y(3), PD(NRPD,3)
    PD(1,1) = Y(1)*(1 - Y(1))*(2.0 - 4.0*Y(3)) - Y(1)*(1.0*Y(3)*(1 - Y(1)) - 1.0*Y(3)*(1 - Y(2)) + Y(1)*(4.0 - 1.0*Y(3)) &
    - Y(1)*(1.0*Y(3) + 3.0) + Y(2)*(5.0 - 2.0*Y(3)) - Y(2)*(2.0*Y(3) + 3.0) - (1.0 - 1.0*Y(3))*(1 - Y(1)) &
    + (1.0 - 1.0*Y(3))*(1 - Y(2))) + (1 - Y(1))*(1.0*Y(3)*(1 - Y(1)) - 1.0*Y(3)*(1 - Y(2)) + Y(1)*(4.0 - 1.0*Y(3)) &
    - Y(1)*(1.0*Y(3) + 3.0) + Y(2)*(5.0 - 2.0*Y(3)) - Y(2)*(2.0*Y(3) + 3.0) - (1.0 - 1.0*Y(3))*(1 - Y(1)) &
    + (1.0 - 1.0*Y(3))*(1 - Y(2)))
    PD(1,2) = Y(1)*(1.0 - 2.0*Y(3))*(1 - Y(1))
    PD(1,3) = Y(1)*(1 - Y(1))*(-4.0*Y(1) - 2.0*Y(2))
    PD(2,1) = Y(2)*(1 - Y(2))*(2.0 - 4.0*Y(3))
    PD(2,2) = Y(2)*(1.0 - 2.0*Y(3))*(1 - Y(2)) - Y(2)*(1.0*Y(3)*(1 - Y(1)) - 1.0*Y(3)*(1 - Y(2)) + Y(1)*(4.0 - 1.0*Y(3)) &
    - Y(1)*(1.0*Y(3) + 3.0) + Y(2)*(5.0 - 2.0*Y(3)) - Y(2)*(2.0*Y(3) + 3.0) - (1.0 - 1.0*Y(3))*(1 - Y(1)) &
    + (1.0 - 1.0*Y(3))*(1 - Y(2))) + (1 - Y(2))*(1.0*Y(3)*(1 - Y(1)) - 1.0*Y(3)*(1 - Y(2)) + Y(1)*(4.0 - 1.0*Y(3)) &
    - Y(1)*(1.0*Y(3) + 3.0) + Y(2)*(5.0 - 2.0*Y(3)) - Y(2)*(2.0*Y(3) + 3.0) - (1.0 - 1.0*Y(3))*(1 - Y(1)) &
    + (1.0 - 1.0*Y(3))*(1 - Y(2)))
    PD(2,3) = Y(2)*(1 - Y(2))*(-4.0*Y(1) - 2.0*Y(2))
    PD(3,1) = 1.25*Y(3)*(1 - Y(3))
    PD(3,2) = 1.25*Y(3)*(1 - Y(3))
    PD(3,3) = -Y(3)*(1.25*Y(1) + 1.25*Y(2) - 1) + (1 - Y(3))*(1.25*Y(1) + 1.25*Y(2) - 1)

    !   Uncomment lines below to dump Jacobian values for debugging
!    DO I=1,3
!        WRITE (6,100) PD(I,1), PD(I,2), PD(I,3)
!    ENDDO
!    100  FORMAT (es12.5, ' ', es12.5, ' ', es12.5)
!
!    WRITE (6,100) Y(1), Y(2), Y(3)

    RETURN
END SUBROUTINE JAC
" >> "${values}.f90"

    echo "----------------------file ${values}.f90----------------------"
    gfortran ${values}.f90 opkdmain.f opkda1.f opkda2.f -o output.out; ./output.out

done


