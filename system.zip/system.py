import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.lines import Line2D
import numpy as np
import re
import pandas as pd
import os.path
from sympy import Matrix, solve, symbols


def read_data(directory, to_read_list=[
        '050401.dat', '070701.dat', '050501.dat', '010901.dat', '090101.dat',
        '050409.dat', '070709.dat', '050509.dat', '010909.dat', '090109.dat']):
    '''
    read_data(directory, to_read_list=[
        '050401.dat', '070701.dat', '050501.dat', '010901.dat', '090101.dat',
        '050409.dat', '070709.dat', '050509.dat', '010909.dat', '090109.dat']):

        Reads through .dat files in to_read_list inside directory
        and gathers their values, saving them
        inside a dictionary whose keys are 'theta05' and 'theta15'.
        Therefore, if the user runs, e.g.,
        read_data(directory=['HD', 'c11c205']), the function will gather
        the values from two models, one with theta = 0.5 and one with
        theta = 1.5, both with M_k = HD and c = 0.5.
        This was made so that the user could easily compare the values
        from these two models.

        Parameters
        -------
        directory: str, path containing .dat files to be read
        to_read_list: list containing strings with values to be read

        Returns
        -------
        model_dict: dict whose items are lists containing the values read

        References
        -------
        a reference to the paper will be provided when it is published
    '''

    model_dict = {'theta05': None, 'theta15': None}

    matches_list = list()
    dir_split = directory.split('/')

    target_dir = os.path.join(
        os.getcwd(),
        dir_split[0],
        str(list(model_dict.keys())[1]),
        dir_split[1]
    )

    for file_to_read in to_read_list:
        for file_in_dir in os.listdir(target_dir):
            if re.fullmatch(file_to_read, file_in_dir):
                matches_list.append(file_in_dir)

    matches_list = sorted(matches_list, key=lambda n: [n[5], n[3]])

    theta05_matches = {
        'theta05': matches_list
    }

    theta15_matches = {
        'theta15': matches_list
    }

    for e, t in enumerate([theta05_matches, theta15_matches]):
        model_list = []
        for i in range(0, len(list(t.values())[0])):
            model = pd.read_fwf(os.path.join(
                os.getcwd(),
                dir_split[0], list(t.keys())[0],
                dir_split[1], t[list(t)[0]][i]),
                colspecs=[
                (1, 10), (11, 21), (22, 32), (33, 43)
            ],
                delimiter=';', names=['t', 'x', 'y', 'n'], nrows=900,
            )

            # condition below takes care of the special case
            # of the HD game (see accompanying paper in References for details)
            if (
                directory[0] == 'HD') and (
                directory[1] == 'c11c21') and (
                    model['x'][0] + model['y'][0] == 1):
                condition = (model['x'] == model['x'][0]) & (
                    model['y'] == model['y'][0])
                model = model[condition]

            # conditions below exclude values of variables < 0 or
            # > 1 from the model object (see accompanying paper in References for details)
            if any(model['y'] < 0) or \
                any(model['n'] < 0) or \
                    any(model['x'] < 0):
                condition = (model['x'] < 0) | (
                    model['y'] < 0) | (model['n'] < 0)
                model = model[0:model[condition].iloc[0].name]
            if any(model['y'] > 1) or \
                any(model['n'] > 1) or \
                    any(model['x'] > 1):
                condition = (model['x'] > 1) | (
                    model['y'] > 1) | (model['n'] > 1)
                model = model[0:model[condition].iloc[0].name]

            # n values should only be gathered
            # up until n < 0.01 (see accompanying paper in References for details)
            if any(model['n'] < 0.01):
                condition = (model['n'] < 0.01)
                model = model[0:model[condition].iloc[0].name + 1]

            model_list.append(model)
        model_dict[list(model_dict.keys())[e]] = model_list

    return model_dict


def make_graphs(model_list, save=False,
                directory_to_save=None, fig_name=None):
    '''
    make_graphs(model_list, save=False,
                directory_to_save=None, fig_name=None):
        Plots the numerical solutions of a model_list objects
        and optionally saves them as <directory_to_save/fig_name>

        Parameters
        -------
        model_list: list, one of the items from model_dict
        returned by read_data
        save: bool, whether to save the figure or not
        directory_to_save: str, path specifying where to save the figure
        fig_name: str, file name for saving the figure

        References
        -------
        a reference to the paper will be provided when it is published
    '''
    plot_list = list(range(0, int(len(model_list) / 2)))
    label_list = []

    plt.close('all')

    plt.rcParams['font.size'] = 14
    color_list = ['#009e73', '#0072b2', '#00e4ff', '#d55e00', '#cc79a7']

    fig = plt.figure(figsize=(17, 7))
    gs = gridspec.GridSpec(nrows=1, ncols=2, wspace=0.1, hspace=0.05)
    ax = fig.add_subplot(gs[0, 0], projection='3d')
    ax.set_xlabel(r"$x$", fontsize=18)
    ax.set_ylabel(r"$y$", fontsize=18)
    ax.set_zlabel(r"$n$", fontsize=18)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_zlim(0, 1)
    label_list = []

    # loop only through the 1st half of the list
    for model in range(0, int(len(model_list) / 2)):
        # creating objects for labelling the plot later
        label1 = model_list[model]['x'][0]
        label2 = model_list[model]['y'][0]
        label3 = model_list[model]['n'][0]
        label_list.append(fr'$x={label1},y={label2},n={label3}$')

        marker = "o"
        if model_list[model]['n']\
                .loc[model_list[model]['n'].size - 1] < .01:
            marker = "x"

        # plot endpoints
        ax.plot(model_list[model]['x'][model_list[model]['x'].size - 1],
                model_list[model]['y'][model_list[model]['y'].size - 1],
                model_list[model]['n'][model_list[model]['n'].size - 1],
                fillstyle=Line2D.fillStyles[-1],
                marker=marker, color=color_list[model], markersize=10,
                markeredgewidth=2)

        # plot the phase trajectory
        plot_list[model], = ax.plot(model_list[model]['x'],
                                    model_list[model]['y'],
                                    model_list[model]['n'],
                                    color=color_list[model],
                                    linewidth=2.5,
                                    label=label_list, linestyle='-')

        # plot starting points
        ax.scatter(model_list[model]['x'][0],
                   model_list[model]['y'][0],
                   model_list[model]['n'][0],
                   s=100, c=color_list[model])

    ax.legend(plot_list, label_list,
              bbox_to_anchor=(0.5, -0.4), loc='lower center',
              ncol=1, borderaxespad=0, fontsize=15, frameon=False)

    ax = fig.add_subplot(gs[0, 1], projection='3d')
    ax.set_xlabel(r"$x$", fontsize=18)
    ax.set_ylabel(r"$y$", fontsize=18)
    ax.set_zlabel(r"$n$", fontsize=18)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_zlim(0, 1)
    label_list = []

    # loop only through the 2nd half of the list
    for model in range(0, int(len(model_list) / 2)):
        # 5 is added to the index so that the loop iterates through
        # the 2nd half of model_list
        label1 = model_list[model + 5]['x'][0]
        label2 = model_list[model + 5]['y'][0]
        label3 = model_list[model + 5]['n'][0]
        label_list.append(fr'$x={label1},y={label2},n={label3}$')

        marker = "o"
        if model_list[model + 5]['n']\
                .loc[model_list[model + 5]['n'].size - 1] < .01:
            marker = "x"

        # plot endpoints
        ax.plot(model_list[model + 5]['x'][model_list[model + 5]
                                           ['x'].size - 1],
                model_list[model + 5]['y'][model_list[model + 5]
                                           ['y'].size - 1],
                model_list[model + 5]['n'][model_list[model + 5]
                                           ['n'].size - 1],
                fillstyle=Line2D.fillStyles[-1],
                marker=marker, color=color_list[model], markersize=10,
                markeredgewidth=2)

        # plot the phase trajectory
        plot_list[model], = ax.plot(model_list[model + 5]['x'],
                                    model_list[model + 5]['y'],
                                    model_list[model + 5]['n'],
                                    color=color_list[model],
                                    linewidth=2.5,
                                    label=label_list, linestyle='-')

        # plot starting points
        ax.scatter(model_list[model + 5]['x'][0],
                   model_list[model + 5]['y'][0],
                   model_list[model + 5]['n'][0],
                   s=100, color=color_list[model])

    ax.legend(plot_list, label_list,
              bbox_to_anchor=(0.5, -0.4), loc='lower center',
              ncol=1, borderaxespad=0, fontsize=15, frameon=False)

    if save and directory_to_save is not None and fig_name is not None:
        save_obj = os.path.join(
            directory_to_save, fig_name)
        plt.savefig(save_obj, dpi=300, bbox_inches='tight')
    elif save and directory_to_save is None:
        raise TypeError(
            '''make_graphs() missing 1 required positional argument:
            \'directory_to_save\'''')
    elif save and fig_name is None:
        raise TypeError(
            '''make_graphs() missing 1 required positional argument:
            \'fig_name\'''')


def get_values(directory, to_read_list=[
        '050401.dat', '070701.dat', '050501.dat', '010901.dat', '090101.dat',
        '050409.dat', '070709.dat', '050509.dat', '010909.dat', '090109.dat'],
        save=False, directory_to_save=None, table_name=None):
    '''
    get_values(directory, to_read_list=[
        '050401.dat', '070701.dat', '050501.dat', '010901.dat', '090101.dat',
        '050409.dat', '070709.dat', '050509.dat', '010909.dat', '090109.dat']):

        Reads through the .dat files in to_read_list inside directory
        and gathers the initial and final values of each of them;
        returns a .tex file containing these values and
        their respective parameter values (M_k, theta and c).

        Parameters
        -------
        directory: str, path containing .dat files to be read
        to_read_list: list containing strings with values to be read
        save: bool, whether to save the values in a .tex file or not
        directory_to_save: str, path specifying where to save the .tex file
        fig_name: str, file name for saving the .tex file

        Returns
        -------
        total: pandas DataFrame containing the initial and final values
        of variables x, y and n and respective parameter values
        (M_k, theta and c) for each file in to_read_list.

        Details
        -------
        The initial and final values of each file are first put into both
        variables_local and variables_to_concat;
        variables_local stores only the initial and final values of each
        subdirectory, i.e., this object is renewed at each subdirectory;
        variables_to_concat stores all the values of all
        subdirectories together.
        Variables_local is necessary only as an index to parameters_local,
        which contains the parameter values of each subdirectory.
        Variables_local and parameters_local are necessary since
        each subdirectory contains different parameter values.
        Several parameters_local objects are concatenated into the
        parameters_to_concat, which is then concatenated
        to variables_to_concat;
        this concatenated data frame is then appended to models_list,
        which is used to
        concatenate all data together, creating the final DataFrame, total.

        References
        -------
        a reference to the paper will be provided when it is published
    '''

    variables_to_concat = pd.DataFrame()
    parameters_to_concat = pd.DataFrame()

    # iterate through directory and all its subdirectories (loop 1)
    for i in os.walk(os.path.join(os.getcwd(), directory)):
        os.chdir(i[0])
        # only read files that are in a final subdirectory in the path
        if len(i[1]) == 0:
            matches_list = list()
            variables_local = pd.DataFrame()

            # iterate through each subdirectory files and then
            # iterate through each item of to_read_list,
            # matching each item to a file_name
            for item in to_read_list:
                for file_name in os.listdir(os.getcwd()):
                    if re.fullmatch(item, file_name):
                        matches_list.append(file_name)

            matches_list = sorted(matches_list, key=lambda n: [n[5], n[3]])

            # loop through matched files (loop 2)
            for match in matches_list:
                model = pd.read_fwf(os.path.join(os.getcwd(), match),
                                    colspecs=[
                                    (1, 10),
                                    (11, 21),
                                    (22, 32),
                                    (33, 43)
                                    ],
                                    delimiter=';',
                                    names=['t', 'x', 'y', 'n'], nrows=3)

                dir_split = os.getcwd().split('/')

                # condition below takes care of the special case
                # of the HD game (see accompanying paper in References for details)
                if (dir_split[-3] == 'HD') and (
                    dir_split[-3] == 'c11c21') and (
                        model['x'][0] + model['y'][0] == 1):
                    condition = (model['x'] == model['x'][0]) & (
                        model['y'] == model['y'][0])
                    model = model[condition]

                # conditions below exclude values of variables < 0 or
                # > 1 from the DataFrames (see accompanying paper in References for details)
                if any(model['x'] < 0) or \
                        any(model['y'] < 0):
                    condition = (model['x'] < 0) | (model['y'] < 0)
                    model = model[0:model[condition].iloc[0].name]

                if any(model['x'] > 1) or \
                    any(model['y'] > 1) or \
                        any(model['n'] > 1):
                    condition = (model['x'] > 1) | (
                        model['y'] > 1) | (model['n'] > 1)
                    model = model[0:model[condition].iloc[0].name]

                model = np.around(model, 3)
                model['t'] = model['t'].array.astype(int)

                # gathering initial and final values
                initial_values = pd.DataFrame(
                    model[['t', 'x', 'y', 'n']].iloc[0:1])
                final_values = pd.DataFrame(
                    model[['t', 'x', 'y', 'n']].iloc[-1::-len(model)])

                # final values should only be gathered
                # up until n < 0.01 (see accompanying paper in References for details)
                if any(model['n'] < 0.01):
                    condition = model['n'] < 0.01
                    model = model[0:model[condition].iloc[0].name]
                    final_values = pd.DataFrame(
                        model[['t', 'x', 'y', 'n']].iloc[-1::-len(model)])

                variables_local = pd.concat(
                    [variables_local, initial_values, final_values],
                    axis=0)
                variables_to_concat = pd.concat(
                    [variables_to_concat, initial_values, final_values],
                    axis=0)
                # end of loop 2

            parameters_local = pd.DataFrame(
                {
                    'M_k': dir_split[-3],
                    'theta': .5 if re.search('0', dir_split[-2]) else 1.5,
                    'c': dir_split[-1][-1] if len(dir_split[-1]) == 6 else
                    dir_split[-1][-2] + '.' + dir_split[-1][-1],
                },
                index=variables_local.index)

            parameters_to_concat = pd.concat(
                [parameters_to_concat, parameters_local], axis=0)
    # end of loop 1

    model_list = list()
    model_list.append(
        pd.concat([parameters_to_concat, variables_to_concat], axis=1))
    total = pd.concat(model_list)  # final DataFrame

    if save and directory_to_save is not None and table_name is not None:
        total.to_latex(os.path.join(directory_to_save, table_name),
                       index=False)
    elif directory_to_save is None:
        raise TypeError(
            '''get_values() missing 1 required positional argument:
            \'directory_to_save\'''')
    elif table_name is None:
        raise TypeError(
            '''get_values() missing 1 required positional argument:
            \'table_name\'''')

    return total


class System:
    '''
    class System()
        Base class for system objects, i.e., class for setting and analyzing
        the dynamical system (see accompanying paper in References for details).

        sub1='PD', sub2='PD', sub3='PD', sub4='PD',
                 c_val=None, theta_val=None)

        Methods defined here:

        solve(self, game = None, t = None)
            Solves the system numerically using sympy's solve function;
            sets the Jacobian matrix for the system using
            sympy's Matrix.jacobian; and evaluates the Jacobian at each
            solution point.

            Returns
            -------
            solutions: list containing the solutions of the system
            jac: sympy.matrices.dense.MutableDenseMatrix,
            Jacobian matrix of the system
            jac_at_point: list containing the Jacobian matrix of the system
            evaluated at each solution point

        eigs(self, save = False)
            Calculates the eigenvalues of the Jacobian matrix at each
            solution point; since looking at the eigenvalues directly isn't
            strictly necessary for determining the stability of the
            equilibrium points, this is a separate method from solve().

            Returns
            -------
            eigenvals: eigenvalues of the system, appended to jac_at_point.

        References
        -------
        a reference to the paper will be provided when it is published

    '''

    x, y, n, theta, c = symbols('x, y, n, theta, c',
                                nonnegative=True)

    def __init__(self,
                 sub1='PD', sub2='PD', sub3='PD', sub4='PD',
                 c_val=None, theta_val=None):
        """

        Parameters
        ----------
        sub1, sub2, sub3 and sub4: str, submatrices M_1,
        M_2, M_3 and M_4. By default, set to a PD game,
        can be changed to an HD game.
        c_val: float, 0 <= c <= 1
        theta_val: float, theta > 0

        Returns
        ----------
        self.env: feedback function
        self.x_rep: differential equation for x variable
        self.y_rep: differential equation for y variable
        self.n_rep: differential equation for n variable
        """

        self.m2sp = np.array([[[3, 0], [5, 1]],
                              [[3, 0], [5, 1]],
                              [[3, 0], [5, 1]],
                              [[3, 0], [5, 1]]], dtype=float)
        self.sub_matrices = np.array([sub1, sub2, sub3, sub4])

        for i, j in enumerate(self.sub_matrices):
            if j == 'HD':
                self.m2sp[i] = [[3, 1], [4, 0]]

        self.c_val, self.theta_val =\
            System.c.subs(System.c, c_val),\
            System.theta.subs(System.theta, theta_val)

        fitCx = System.x * (self.m2sp[0, 1, 0] - (self.m2sp[0, 1, 0] - self.m2sp[0, 0, 0]) * System.n) +\
            (1 - System.x) * (self.m2sp[0, 1, 1] - (self.m2sp[0, 1, 1] - self.m2sp[0, 0, 1]) * System.n) +\
            System.y * (self.m2sp[1, 1, 0] - (self.m2sp[1, 1, 0] - self.m2sp[1, 0, 0]) * System.n) +\
            (1 - System.y) * (self.m2sp[1, 1, 1] -
                              (self.m2sp[1, 1, 1] - self.m2sp[1, 0, 1]) * System.n)

        fitDx = System.x * (self.m2sp[0, 0, 0] + (self.m2sp[0, 1, 0] - self.m2sp[0, 0, 0]) * System.n) +\
            (1 - System.x) * (self.m2sp[0, 0, 1] + (self.m2sp[0, 1, 1] - self.m2sp[0, 0, 1]) * System.n) +\
            System.y * (self.m2sp[1, 0, 0] + (self.m2sp[1, 1, 0] - self.m2sp[1, 0, 0]) * System.n) +\
            (1 - System.y) * (self.m2sp[1, 0, 1] +
                              (self.m2sp[1, 1, 1] - self.m2sp[1, 0, 1]) * System.n)

        fitCy = System.x * (self.m2sp[2, 1, 0] - (self.m2sp[2, 1, 0] - self.m2sp[2, 0, 0]) * System.n * self.c_val) +\
            (1 - System.x) * (self.m2sp[2, 1, 1] - (self.m2sp[2, 1, 1] - self.m2sp[2, 0, 1]) * System.n * self.c_val) +\
            System.y * (self.m2sp[3, 1, 0] - (self.m2sp[3, 1, 0] - self.m2sp[3, 0, 0]) * System.n) +\
            (1 - System.y) * (self.m2sp[3, 1, 1] -
                              (self.m2sp[3, 1, 1] - self.m2sp[3, 0, 1]) * System.n)

        fitDy = System.x * (self.m2sp[2, 0, 0] + (self.m2sp[2, 1, 0] - self.m2sp[2, 0, 0]) * System.n * self.c_val) +\
            (1 - System.x) * (self.m2sp[2, 0, 1] + (self.m2sp[2, 1, 1] - self.m2sp[2, 0, 1]) * System.n * self.c_val) +\
            System.y * (self.m2sp[3, 0, 0] + (self.m2sp[3, 1, 0] - self.m2sp[3, 0, 0]) * System.n) +\
            (1 - System.y) * (self.m2sp[3, 0, 1] +
                              (self.m2sp[3, 1, 1] - self.m2sp[3, 0, 1]) * System.n)

        self.env = self.theta_val * ((System.x + System.y) / 2) - (
            (1 - System.x + 1 - System.y) / 2)

        self.x_rep = System.x * (1 - System.x) * (fitCx - fitDx)
        self.y_rep = System.y * (1 - System.y) * (fitCy - fitDy)
        self.n_rep = System.n * (1 - System.n) * self.env

    def solve(self):
        '''
        Solves the system using sympy's solve function;
        sets the Jacobian matrix for the system
        using sympy's Matrix.jacobian;
        and evaluates the Jacobian at each solution point.

        Returns
        -------
        solutions: list containing the solutions of the system
        jac: sympy.matrices.dense.MutableDenseMatrix,
        Jacobian matrix of the system
        jac_at_point: list containing the Jacobian matrix of
        the system evaluated at each solution point
        '''

        self.solutions = solve([self.x_rep, self.y_rep, self.n_rep],
                               System.x, System.y, System.n, dict=True)

        functions = Matrix([self.x_rep, self.y_rep, self.n_rep])
        variables = Matrix([System.x, System.y, System.n])

        self.jac = Matrix.jacobian(functions, variables)

        # evaluating the jacobian at every solution point and
        # appending these to jac_at_point
        self.jac_at_point = []
        for i in self.solutions:
            self.jac_at_point.append(self.jac.subs([
                                    (list(i.items())[0][0],
                                        list(i.items())[0][1]),
                                    (list(i.items())[1][0],
                                        list(i.items())[1][1])]))

        return self.jac, self.jac_at_point


def str_rep(str_to_rep):
    new_str = str_to_rep.replace('x', 'Y(1)')
    new_str = new_str.replace('y', 'Y(2)')
    new_str = new_str.replace('n', 'Y(3)')
    new_str = new_str + '\n'
    return new_str


# example
# ---------
# running read_data with the folder <path>/HD/c11c205 as input
# models = read_data('HD/c11c205')

# plotting the graph corresponding to the model with theta=0.5
# make_graphs(models['theta05'], save=True,
#             directory_to_save=<path>, fig_name='testfig')

# running get_values for all games with HD
# total = get_values('HD', save=True,
#                    directory_to_save=<path>, table_name='test.tex')
